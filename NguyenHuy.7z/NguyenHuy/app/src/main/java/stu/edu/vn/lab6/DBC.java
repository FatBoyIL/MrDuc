package stu.edu.vn.lab6;

public class DBC {
    public static final String DATABASE_NAME = "FRIENDS_DB";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME ="FRIENDS_TABLE";

    public static final String C_ID="ID";
    public static final String C_NAME="NAME";
    public static final String C_NICKNAME="NICKNAME";
    public static final String C_DATE="BIRTHDATE";
    public static final String C_FB="FB";
    public static final String C_INS="INSTA";
    public static final String C_X="X";

    public static final String C_ZALO="ZALO";
    public static final String C_GMAIL="GMAIL";

    public static final String C_IMAGE="IMAGE";

    //CRAETE DB
    public static final String CREATE_TABLE = "CREATE TABLE "+TABLE_NAME+"("
            +C_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "
            +C_NAME+ " VARCHAR(50), "
            +C_NICKNAME+ " VARCHAR(50), "
            +C_DATE+ " VARCHAR(50), "
            +C_FB+ " VARCHAR(50), "
            +C_INS+ " VARCHAR(50), "
            +C_X+ " VARCHAR(50), "
            +C_ZALO+ " VARCHAR(50), "
            +C_GMAIL+ " VARCHAR(50), "
            +C_IMAGE+ " VARCHAR(50)"
            + " );";

}

