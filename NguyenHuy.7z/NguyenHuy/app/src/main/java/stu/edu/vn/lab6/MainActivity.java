package stu.edu.vn.lab6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;



public class MainActivity extends AppCompatActivity {
    FloatingActionButton fab;
    ListView frListView; // Thay thế RecyclerView bằng ListView

    DBHelper dbHelper;
    AdapterFriend adapterFriend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new DBHelper(this);

        fab = findViewById(R.id.fabAdd);
        frListView = findViewById(R.id.frListView); // Thay thế R.id.frRv bằng R.id.frListView

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListFriend.class);
                startActivity(intent);
            }
        });

        registerForContextMenu(frListView); // Đăng ký ContextMenu cho ListView
        loadData();
    }

    private void loadData() {
        adapterFriend = new AdapterFriend(this, dbHelper.getAllData());
        frListView.setAdapter(adapterFriend);

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData(); // refresh data
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mnu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if (itemId == R.id.mnuThoat) {
            finish();
            System.exit(0);
        }
        return super.onOptionsItemSelected(item);
    }

    // Thêm phương thức này để xử lý khi một mục trên ListView được nhấn giữ
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.mnu_main, menu);
    }

}