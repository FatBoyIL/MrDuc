package stu.edu.vn.lab6;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import stu.edu.vn.lab6.DBHelper;
import stu.edu.vn.lab6.FriendDetail;
import stu.edu.vn.lab6.FriendModel;
import stu.edu.vn.lab6.ListFriend;
import stu.edu.vn.lab6.R;

public class AdapterFriend extends ArrayAdapter<FriendModel> {

    private Context context;
    private ArrayList<FriendModel> friendList;
    private DBHelper dbHelper;

    public AdapterFriend(Context context, ArrayList<FriendModel> friendList) {
        super(context, 0, friendList);
        this.context = context;
        this.friendList = friendList;
        dbHelper = new DBHelper(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        FriendViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.row_friend_item, parent, false);
            holder = new FriendViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (FriendViewHolder) convertView.getTag();
        }

        //show 3 data
        FriendModel friendModel = friendList.get(position);
        String id = friendModel.getId();
        String name = friendModel.getName();
        String nickname = friendModel.getNickname();
        String date = friendModel.getBirthday();
        String fb = friendModel.getFb();
        String ins = friendModel.getIns();
        String x = friendModel.getX();
        String zalo = friendModel.getZalo();
        String mail = friendModel.getGmail();
        String img = friendModel.getImg();

        //set data in View
        holder.friendName.setText(name);
        if (img.equals("")) {
            holder.friendImg.setImageResource(R.drawable.doraemon);
        } else {
            holder.friendImg.setImageURI(Uri.parse(img));
        }

        holder.friendName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, FriendDetail.class);
                intent.putExtra("friendID", id);
                context.startActivity(intent);
            }
        });

        holder.setDial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ListFriend.class);
                intent.putExtra("idFix", id);
                intent.putExtra("nicknameFix", nickname);
                intent.putExtra("nameFix", name);
                intent.putExtra("dateFix", date);
                intent.putExtra("fbFix", fb);
                intent.putExtra("insFix", ins);
                intent.putExtra("xFix", x);
                intent.putExtra("zaloFix", zalo);
                intent.putExtra("mailFix", mail);
                intent.putExtra("imageFix", img);
                intent.putExtra("isEdit", true);
                context.startActivity(intent);
            }
        });

        holder.delDial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper.deleteFriend(id);
                remove(friendModel);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }

    class FriendViewHolder {
        ImageView friendImg, setDial, delDial;
        TextView friendName;

        public FriendViewHolder(View itemView) {
            friendImg = itemView.findViewById(R.id.imgListF);
            friendName = itemView.findViewById(R.id.txtFriendName);
            setDial = itemView.findViewById(R.id.SetDial);
            delDial = itemView.findViewById(R.id.DelDial);
        }
    }
}
