package stu.edu.vn.lab6;


import static android.provider.MediaStore.ACTION_IMAGE_CAPTURE;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class ListFriend extends AppCompatActivity {


    EditText edtDate, edtName, edtNickname, edtMail, edtFb, edtIns, edtX, edtZalo;
    ImageButton btnDate;
    ImageView imgFriends;

    String id,name,nickname,date,fb,ins,x,zalo,mail,image;
    Boolean isEdit;

    Button btnAddF;

    private DBHelper dbHelper;

    private static final int PERMISSION_CODE = 100;

    private static final int CAPTURE_CODE = 132 ;
    Uri imgURI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_friend);

        dbHelper = new DBHelper(this);

        imgFriends = findViewById(R.id.imgFriends);
        btnDate = findViewById(R.id.btnDate);



        //anh xa
        edtName = findViewById(R.id.edtNameF);
        edtNickname = findViewById(R.id.edtnickNameF);
        edtMail = findViewById(R.id.edtMailF);
        edtFb = findViewById(R.id.edtfbF);
        edtIns = findViewById(R.id.edtInsF);
        edtX = findViewById(R.id.edtXF);
        edtZalo = findViewById(R.id.edtZaloF);
        edtDate = findViewById(R.id.txtDate);
        btnAddF = findViewById(R.id.btnAddF);

        Intent intent = getIntent();
        isEdit = intent.getBooleanExtra("isEdit",false);

        if (isEdit){
            id =intent.getStringExtra("idFix");
            nickname = intent.getStringExtra("nicknameFix");
            name = intent.getStringExtra("nameFix");
            date = intent.getStringExtra("dateFix");
            fb = intent.getStringExtra("fbFix");
            ins = intent.getStringExtra("insFix");
            x = intent.getStringExtra("xFix");
            zalo = intent.getStringExtra("zaloFix");
            mail = intent.getStringExtra("mailFix");
            image = intent.getStringExtra("imageFix");


            edtName.setText(name);
            edtNickname.setText(nickname);
            edtDate.setText(date);
            edtFb.setText(fb);
            edtIns.setText(ins);
            edtX.setText(x);
            edtZalo.setText(zalo);
            edtMail.setText(mail);

            imgURI = Uri.parse(image);
            if (image.equals("")){
                imgFriends.setImageResource(R.drawable.doraemon);
            }else {
                imgFriends.setImageURI(imgURI);
            }

        }else {

        }
        //update img
        imgFriends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                showImgPickerDialog();
                if (checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_DENIED ||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)==PackageManager.PERMISSION_DENIED)
                {
                    String []permission={Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE};
                    requestPermissions(permission,PERMISSION_CODE);
                }else {
                    openCamera();
                }
            }
        });
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDatePicker();
            }
        });
        btnAddF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
            }
        });

    }

    private void openCamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE,"new image");
        values.put(MediaStore.Images.Media.DESCRIPTION,"From the camera");
        imgURI = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        Intent intent = new Intent(ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT,imgURI);
        startActivityForResult(intent,CAPTURE_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case PERMISSION_CODE:
                if (grantResults.length > 0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) {
                    openCamera();
                }else {
                    Toast.makeText(getApplicationContext(), "Chưa cấp quyền cho store", Toast.LENGTH_LONG).show();
                }
        }
    }
    @SuppressLint("MissingSuperCall")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == PERMISSION_CODE) {
                imgFriends.setImageURI(imgURI);
            }
        }
    }

    private void openDatePicker() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, androidx.appcompat.R.style.Widget_AppCompat_ActionBar, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                //Showing the picked value in the textView
                edtDate.setText(String.valueOf(year) + "." + String.valueOf(month + 1) + "." + String.valueOf(day));
            }
        }, 2023, 01, 20);

        datePickerDialog.show();
    }

    private void saveData() {
        name = edtName.getText().toString();
        nickname = edtNickname.getText().toString();
        mail = edtMail.getText().toString();
        fb = edtFb.getText().toString();
        ins = edtIns.getText().toString();
        x = edtX.getText().toString();
        zalo = edtZalo.getText().toString();
        date = edtDate.getText().toString();
        if (imgURI == null) {
            imgFriends.setImageResource(R.drawable.doraemon);
        } else {
            if (isEdit) {
                dbHelper.updateFriend(
                        "" + id,
                        ""+nickname,
                        "" + name,
                        "" + date,
                        "" + fb,
                        "" + ins,
                        "" + x,
                        "" + zalo,
                        "" + mail,
                        "" + imgURI
                );
                Toast.makeText(getApplicationContext(), "Updated ", Toast.LENGTH_LONG).show();
            } else {
                long id = dbHelper.insertFriend(
                        "" + name,
                        ""+nickname,
                        "" + date,
                        "" + fb,
                        "" + ins,
                        "" + x,
                        "" + zalo,
                        "" + mail,
                        "" + imgURI
                );
                Toast.makeText(getApplicationContext(), "Inserted ", Toast.LENGTH_LONG).show();

            }
        }
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
       AlertDialog.Builder mydialog = new AlertDialog.Builder(ListFriend.this);
       mydialog.setTitle("Confirm");
       mydialog.setMessage("Hãy chắc chắn những thông tin bạn vừa nhập nhé !");
       mydialog.setPositiveButton("Có", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {
               finish();
           }
       });
       mydialog.setNegativeButton("Khoan đã", new DialogInterface.OnClickListener() {
           @Override
           public void onClick(DialogInterface dialog, int which) {
               dialog.cancel();
           }
       });
        mydialog.create().show();
    }
}