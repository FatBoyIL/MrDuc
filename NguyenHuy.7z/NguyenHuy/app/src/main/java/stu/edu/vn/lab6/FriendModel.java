package stu.edu.vn.lab6;


public class FriendModel {
    private String id,name,nickname,birthday,fb,ins,x,zalo,gmail,img;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getFb() {
        return fb;
    }

    public void setFb(String fb) {
        this.fb = fb;
    }

    public String getIns() {
        return ins;
    }

    public void setIns(String ins) {
        this.ins = ins;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getZalo() {
        return zalo;
    }

    public void setZalo(String zalo) {
        this.zalo = zalo;
    }

    public String getGmail() {
        return gmail;
    }

    public void setGmail(String gmail) {
        this.gmail = gmail;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public FriendModel(String id, String name, String nickname, String birthday, String fb, String ins, String x, String zalo, String gmail, String img) {
        this.id = id;
        this.name = name;
        this.nickname = nickname;
        this.birthday = birthday;
        this.fb = fb;
        this.ins = ins;
        this.x = x;
        this.zalo = zalo;
        this.gmail = gmail;
        this.img = img;
    }
}

