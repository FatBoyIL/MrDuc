package stu.edu.vn.lab6;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class FriendDetail extends AppCompatActivity {

    TextView nameDT,birthDT,fbDT,insDT,xDT,zaloDT,mailDT;
    ImageView imgDT;

    String id;
    DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend_detail);

        dbHelper = new DBHelper(this);

        Intent intent = getIntent();
        id = intent.getStringExtra("friendID");


        nameDT=findViewById(R.id.txtnickameDetail);
        birthDT=findViewById(R.id.DetailBirth);
        fbDT=findViewById(R.id.DetailFB);
        insDT=findViewById(R.id.DetailINS);
        xDT=findViewById(R.id.DetailX);
        zaloDT=findViewById(R.id.DetailZalo);
        mailDT=findViewById(R.id.DetailMail);
        imgDT=findViewById(R.id.imgDetail);

        loadDataIDFR();
    }

    public void loadDataIDFR() {
        String select = "SELECT * FROM "+DBC.TABLE_NAME+ " WHERE " + DBC.C_ID + "=\"" + id + "\"";
        SQLiteDatabase database = dbHelper.getReadableDatabase();
        Cursor cursor = database.rawQuery(select,null);
        if (cursor.moveToFirst()){
            do{

                String nickname = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_NICKNAME));
                String date = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_DATE));
                String fb = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_FB));
                String ins = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_INS));
                String x = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_X));
                String zalo = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_ZALO));
                String mail = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_GMAIL));
                String img = "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_IMAGE));

                nameDT.setText(nickname);
                birthDT.setText(date);
                fbDT.setText(fb);
                insDT.setText(ins);
                xDT.setText(x);
                zaloDT.setText(zalo);
                mailDT.setText(mail);
                if (img.isEmpty()){
                    imgDT.setImageResource(R.drawable.doraemon);
                }else {
                    imgDT.setImageURI(Uri.parse(img));
                }
            }while (cursor.moveToNext());
        }
        database.close();
    }
}