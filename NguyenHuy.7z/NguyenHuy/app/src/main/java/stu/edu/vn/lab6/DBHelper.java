package stu.edu.vn.lab6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public DBHelper(@Nullable Context context) {
        super(context,DBC.DATABASE_NAME,null,DBC.DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DBC.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + DBC.TABLE_NAME);//delete table old
        onCreate(db);
    }

    public long insertFriend(String name,String nickname,String date,String fb,String ins,String x,String zalo,String mail,String img)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DBC.C_NAME,name);
        contentValues.put(DBC.C_NICKNAME,nickname);
        contentValues.put(DBC.C_DATE,date);
        contentValues.put(DBC.C_FB,fb);
        contentValues.put(DBC.C_INS,ins);
        contentValues.put(DBC.C_X,x);
        contentValues.put(DBC.C_ZALO,zalo);
        contentValues.put(DBC.C_GMAIL,mail);
        contentValues.put(DBC.C_IMAGE,img);
        long id = db.insert(DBC.TABLE_NAME,null,contentValues);
        db.close();
        return id;
    }

    public void updateFriend(String id ,String nickname,String name,String date,String fb,String ins,String x,String zalo,String mail,String img)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DBC.C_NAME,name);
        contentValues.put(DBC.C_NICKNAME,nickname);
        contentValues.put(DBC.C_DATE,date);
        contentValues.put(DBC.C_FB,fb);
        contentValues.put(DBC.C_INS,ins);
        contentValues.put(DBC.C_X,x);
        contentValues.put(DBC.C_ZALO,zalo);
        contentValues.put(DBC.C_GMAIL,mail);
        contentValues.put(DBC.C_IMAGE,img);
        db.update(DBC.TABLE_NAME,contentValues,DBC.C_ID+ " =? ",new String[]{id});
        db.close();
    }

    public void deleteFriend(String id){
        SQLiteDatabase database = getWritableDatabase();
        database.delete(DBC.TABLE_NAME, DBC.C_ID + " = ?", new String[]{id});
        database.close();
    }

    //getData
    public ArrayList<FriendModel> getAllData(){
        ArrayList<FriendModel> arrayList = new ArrayList<>();
        String selectQuery ="SELECT * FROM "+DBC.TABLE_NAME;
        SQLiteDatabase database = getReadableDatabase();
        Cursor cursor = database.rawQuery(selectQuery,null);
        if (cursor.moveToFirst()){
            do{
                FriendModel friendModel= new FriendModel(
                        "" + cursor.getInt(cursor.getColumnIndexOrThrow(DBC.C_ID)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_NAME)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_NICKNAME)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_DATE)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_FB)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_INS)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_X)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_ZALO)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_GMAIL)),
                        "" + cursor.getString(cursor.getColumnIndexOrThrow(DBC.C_IMAGE))
                );
                arrayList.add(friendModel);
            }while (cursor.moveToNext());
        }
        database.close();
        return arrayList;
    }
}

